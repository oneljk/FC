import 'package:flutter/material.dart';

class CalculatorHome extends StatefulWidget {
  const CalculatorHome({Key? key}) : super(key: key);

  @override
  State<CalculatorHome> createState() => _CalculatorHomeState();
}

class _CalculatorHomeState extends State<CalculatorHome> {
  String input = "";
  String output = "";

  void onButtonClick(String value) {
    setState(() {
      if (value == "C") {
        input = "";
        output = "";
      } else if (value == "=") {
        try {
          output = _calculateResult(input);
        } catch (e) {
          output = "Error";
        }
      } else {
        input += value;
      }
    });
  }

  String _calculateResult(String exp) {
    double num1 = 0;
    double num2 = 0;
    String op = "";

    // find operator
    if (exp.contains("+")) op = "+";
    if (exp.contains("-")) op = "-";
    if (exp.contains("*")) op = "*";
    if (exp.contains("/")) op = "/";

    List<String> parts = exp.split(op);

    num1 = double.parse(parts[0]);
    num2 = double.parse(parts[1]);

    double result = 0;

    switch (op) {
      case "+":
        result = num1 + num2;
        break;
      case "-":
        result = num1 - num2;
        break;
      case "*":
        result = num1 * num2;
        break;
      case "/":
        result = num2 != 0 ? num1 / num2 : 0;
        break;
    }

    return result.toString();
  }

  Widget buildButton(String text) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(6),
        child: ElevatedButton(
          onPressed: () => onButtonClick(text),
          child: Text(
            text,
            style: const TextStyle(fontSize: 22),
          ),
          style: ElevatedButton.styleFrom(padding: const EdgeInsets.all(20)),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Calculator")),
      body: Column(
        children: [
          // Display Area
          Container(
            alignment: Alignment.centerRight,
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Text(
                  input,
                  style: const TextStyle(fontSize: 30, color: Colors.black54),
                ),
                const SizedBox(height: 10),
                Text(
                  output,
                  style: const TextStyle(
                      fontSize: 36, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
          const Divider(),
          // Buttons
          Expanded(
            child: Column(
              children: [
                Row(children: [
                  buildButton("7"),
                  buildButton("8"),
                  buildButton("9"),
                  buildButton("/")
                ]),
                Row(children: [
                  buildButton("4"),
                  buildButton("5"),
                  buildButton("6"),
                  buildButton("*")
                ]),
                Row(children: [
                  buildButton("1"),
                  buildButton("2"),
                  buildButton("3"),
                  buildButton("-")
                ]),
                Row(children: [
                  buildButton("0"),
                  buildButton("C"),
                  buildButton("="),
                  buildButton("+")
                ]),
              ],
            ),
          )
        ],
      ),
    );
  }
}
