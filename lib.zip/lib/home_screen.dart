// lib/home_screen.dart
import 'package:flutter/material.dart';

class AgeHomeScreen extends StatefulWidget {
  const AgeHomeScreen({Key? key}) : super(key: key);

  @override
  State<AgeHomeScreen> createState() => _AgeHomeScreenState();
}

class _AgeHomeScreenState extends State<AgeHomeScreen> {
  DateTime? _selectedDob;
  int? _ageYears;

  // Calculate completed years between dob and today
  int _calculateAgeYears(DateTime dob) {
    final today = DateTime.now();
    int years = today.year - dob.year;

    // Subtract 1 if birthday hasn't occurred yet this year
    final hadBirthdayThisYear = (today.month > dob.month) ||
        (today.month == dob.month && today.day >= dob.day);
    if (!hadBirthdayThisYear) years -= 1;

    return years;
  }

  Future<void> _pickDob() async {
    final today = DateTime.now();
    final initial = _selectedDob ?? DateTime(today.year, today.month, today.day);
    final firstDate = DateTime(1900);
    final lastDate = today;

    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: firstDate,
      lastDate: lastDate,
    );

    if (picked != null) {
      setState(() {
        _selectedDob = picked;
        _ageYears = _calculateAgeYears(picked);
      });
    }
  }

  String _formatDob(DateTime? d) {
    if (d == null) return 'No date selected';
    // simple dd-mm-yyyy format so no external package needed
    final dd = d.day.toString().padLeft(2, '0');
    final mm = d.month.toString().padLeft(2, '0');
    final yyyy = d.year.toString();
    return '$dd-$mm-$yyyy';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Age Calculator')),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Select your Date of Birth',
              style: TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 12),
            Text(
              _formatDob(_selectedDob),
              style: const TextStyle(fontSize: 16, color: Colors.black87),
            ),
            const SizedBox(height: 18),
            ElevatedButton.icon(
              onPressed: _pickDob,
              icon: const Icon(Icons.calendar_today),
              label: const Text('Pick DOB'),
            ),
            const SizedBox(height: 28),
            if (_ageYears != null)
              Column(
                children: [
                  const Text('Your age is:', style: TextStyle(fontSize: 16)),
                  const SizedBox(height: 8),
                  Text(
                    '$_ageYears years',
                    style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
                  ),
                ],
              )
            else
              const Text(
                'Please select your DOB to see age',
                style: TextStyle(fontSize: 14, color: Colors.grey),
              ),
          ],
        ),
      ),
    );
  }
}
