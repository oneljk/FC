<?php
$cn = new mysqli("localhost", "root", "", "flutter_api");
if ($cn->connect_error) {
    die("DB Error");
}
?>
