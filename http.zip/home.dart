import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List users = [];

  final TextEditingController nameC = TextEditingController();
  final TextEditingController emailC = TextEditingController();

  // Change the IP when testing on physical device
  // final String api = "http://10.0.2.2/home/api.php"; // for Android emulator
  final String api = "http://localhost/api/api.php"; // for web

  @override
  void initState() {
    super.initState();
    fetchUsers();
  }

  // --------------------- READ ---------------------
  Future<void> fetchUsers() async {
    var url = Uri.parse("$api?action=get");
    var response = await http.get(url);
    setState(() {
      users = jsonDecode(response.body);
    });
  }

  // --------------------- ADD ---------------------
  Future<void> addUser() async {
    var url = Uri.parse("$api?action=add");
    await http.post(url, body: {
      "name": nameC.text,
      "email": emailC.text,
    });
    fetchUsers();
  }

  // --------------------- UPDATE ---------------------
  Future<void> updateUser(String id) async {
    var url = Uri.parse("$api?action=update");
    await http.post(url, body: {
      "id": id,
      "name": nameC.text,
      "email": emailC.text,
    });
    fetchUsers();
  }

  // --------------------- DELETE ---------------------
  Future<void> deleteUser(String id) async {
    var url = Uri.parse("$api?action=delete");
    await http.post(url, body: {"id": id});
    fetchUsers();
  }

  // --------------------- POPUP FORM ---------------------
  void openForm({String? id}) {
    if (id == null) {
      nameC.clear();
      emailC.clear();
    }

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(id == null ? "Add User" : "Update User"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameC,
              decoration: const InputDecoration(labelText: "Name"),
            ),
            TextField(
              controller: emailC,
              decoration: const InputDecoration(labelText: "Email"),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              if (id == null) {
                addUser();
              } else {
                updateUser(id);
              }
              Navigator.pop(context);
            },
            child: Text(id == null ? "Add" : "Update"),
          )
        ],
      ),
    );
  }

  // --------------------- UI ---------------------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Flutter + PHP CRUD")),

      floatingActionButton: FloatingActionButton(
        onPressed: () => openForm(),
        child: const Icon(Icons.add),
      ),

      body: users.isEmpty
          ? const Center(child: Text("No Data Found"))
          : ListView.builder(
              itemCount: users.length,
              itemBuilder: (context, index) {
                var u = users[index];
                return Card(
                  child: ListTile(
                    title: Text(u["name"]),
                    subtitle: Text(u["email"]),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                            icon: const Icon(Icons.edit),
                            onPressed: () {
                              nameC.text = u["name"];
                              emailC.text = u["email"];
                              openForm(id: u["id"]);
                            }),
                        IconButton(
                            icon: const Icon(Icons.delete),
                            onPressed: () => deleteUser(u["id"])),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
