<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: *");
header("Content-Type: application/json");

$cn = new mysqli("localhost", "root", "", "flutter_api");
if ($cn->connect_error) {
    die(json_encode(["error" => "DB connection failed"]));
}

// Get the action from query ?action=get|add|update|delete
$action = $_GET['action'] ?? '';

switch ($action) {

    // ---------------------------------------------------------
    // READ ALL USERS
    // ---------------------------------------------------------
    case "get":
        $res = $cn->query("SELECT * FROM users");
        $data = [];
        while ($row = $res->fetch_assoc()) {
            $data[] = $row;
        }
        echo json_encode($data);
        break;

    // ---------------------------------------------------------
    // ADD USER
    // ---------------------------------------------------------
    case "add":
        $name = $_POST['name'] ?? '';
        $email = $_POST['email'] ?? '';

        $cn->query("INSERT INTO users (name,email) VALUES('$name','$email')");
        echo json_encode(["status" => "success"]);
        break;

    // ---------------------------------------------------------
    // UPDATE USER
    // ---------------------------------------------------------
    case "update":
        $id = $_POST['id'] ?? '';
        $name = $_POST['name'] ?? '';
        $email = $_POST['email'] ?? '';

        $cn->query("UPDATE users SET name='$name', email='$email' WHERE id=$id");
        echo json_encode(["status" => "updated"]);
        break;

    // ---------------------------------------------------------
    // DELETE USER
    // ---------------------------------------------------------
    case "delete":
        $id = $_POST['id'] ?? '';
        $cn->query("DELETE FROM users WHERE id=$id");
        echo json_encode(["status" => "deleted"]);
        break;

    // ---------------------------------------------------------
    default:
        echo json_encode(["error" => "Invalid action"]);
}
?>
